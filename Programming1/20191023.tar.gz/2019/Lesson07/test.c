// 学籍番号：4619072　氏名：服部　翼
#include <stdio.h>

int main(void)
{
    printf("%d\n",  'a');

    return 0;
}
